# plugin.video.star.plus
## Español
Star+ para Kodi

Es casi usable!

Esta es una version modificada del addon Disney+ de slyguy

Yo no tengo tiempo para para trabajar en esto, si estas interesado en continuar este trabajo eres biemvenido

Funciona para Series, Peliculas y Eventos en vivo (En Destacados), en este ultimo puede que tengas que seleccionar una tasa de trasnferencia baja (~3.1Mbit/s) para que funcione apropiadamente.

Instalación:
- Primero que nada instala el repo de slyguy, y instala el addon de Disney+ (por las dependencias)
- Copia este repositorio a .kodi/addons, en algo como plugin.video.star.plus
- Habilita el addon en Mis addons, de ser necesario
- Ve al addon y haz login usando tus credenciales

---
## English
Star+ for kodi

Is almost a usable thing!

This is a modified version of the Disney+ from slyguy.

I have no time to work on this, if you want to continue this work you are welcome.

Works for Series, Movies and Live events (bellow Featured), on this last one you may need to chose a low bitrate (~3.1Mbit/s) for work propperly

Install:
- First of all,  Install slyguy repo, and install Disney+ addon (for dependences)
- Copy this repo to .kodi/addons, on somithing like plugin.video.star.plus
- Enable the addon on My Addons
- Go to the addon, login using yours credentials.

IMPORTANT: Dont trust me, dont trust anybody. Check the differences (use diff) with the Disney+ code so you can see this is not a fake addon with the porpouse of to stealing users and passwords

### NOTES:
- Use of diff:
<code>
$ cd .kodi/addons
$ diff -r plugin.video.star.plus/ slyguy.disney.plus/
</code>

- I stole most of this to slyguy www.matthuisman.nz on https://github.com/matthuisman/slyguy.addons, his repo https://k.slyguy.xyz/.repo/
